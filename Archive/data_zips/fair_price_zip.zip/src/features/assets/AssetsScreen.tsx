import * as React from "react";
import { GlassCard, GlassPanel } from "@/components/ui/glass";
import { HeroValuationCard } from "@/components/ui/hero-valuation-card";

export function AssetsScreen() {
  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-10 items-center justify-center p-4">
      <HeroValuationCard value="12.45" />

      <div className="w-full max-w-4xl flex flex-col gap-4">
        <div className="flex justify-between items-end border-b border-white/5 pb-2">
            <h2 className="font-headline-lg-mobile text-on-surface">Direct Comparables</h2>
            <span className="font-label-caps text-outline">Match &gt; 85%</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassPanel className="p-5 flex flex-col gap-4 border border-white/5 hover:-translate-y-1 transition-transform">
                <div className="flex justify-between items-start">
                    <div className="flex flex-col">
                        <span className="font-data-tabular text-on-surface font-semibold">Apex Tower Unit 42B</span>
                        <span className="font-label-caps text-on-surface-variant mt-1">0.4km Distance</span>
                    </div>
                    <div className="bg-primary-container/20 px-3 py-1 rounded-full border border-primary-fixed/30 flex items-center gap-1">
                        <span className="font-data-tabular text-primary-fixed font-bold">94%</span>
                    </div>
                </div>
                <div className="flex justify-between items-end mt-4 pt-4 border-t border-white/5">
                    <div className="flex flex-col">
                        <span className="font-label-caps text-outline">Sold Price</span>
                        <span className="font-data-tabular text-on-surface text-lg">EGP 13.1M</span>
                    </div>
                    <button className="text-primary-fixed font-label-caps hover:text-primary transition-colors flex items-center gap-1">
                        Analyze →
                    </button>
                </div>
            </GlassPanel>

            <GlassPanel className="p-5 flex flex-col gap-4 border border-white/5 hover:-translate-y-1 transition-transform">
                <div className="flex justify-between items-start">
                    <div className="flex flex-col">
                        <span className="font-data-tabular text-on-surface font-semibold">Lumina Residences PH2</span>
                        <span className="font-label-caps text-on-surface-variant mt-1">1.1km Distance</span>
                    </div>
                    <div className="bg-primary-container/10 px-3 py-1 rounded-full border border-primary-fixed/30 flex items-center gap-1">
                        <span className="font-data-tabular text-primary-fixed font-bold opacity-80">89%</span>
                    </div>
                </div>
                <div className="flex justify-between items-end mt-4 pt-4 border-t border-white/5">
                    <div className="flex flex-col">
                        <span className="font-label-caps text-outline">Sold Price</span>
                        <span className="font-data-tabular text-on-surface text-lg">EGP 11.9M</span>
                    </div>
                    <button className="text-primary-fixed font-label-caps hover:text-primary transition-colors flex items-center gap-1">
                        Analyze →
                    </button>
                </div>
            </GlassPanel>
        </div>
      </div>
    </div>
  );
}
