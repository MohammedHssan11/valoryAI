import * as React from "react";
import { GlassCard } from "@/components/ui/glass";
import { AiOrb } from "@/components/ui/ai-orb";
import { motion, AnimatePresence } from "motion/react";

export function BrokerScreen() {
  const [step, setStep] = React.useState(0);

  React.useEffect(() => {
    const timer1 = setTimeout(() => setStep(1), 800);
    const timer2 = setTimeout(() => setStep(2), 2400);
    const timer3 = setTimeout(() => setStep(3), 4000);
    return () => { clearTimeout(timer1); clearTimeout(timer2); clearTimeout(timer3); };
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-8 items-center justify-center p-4 min-h-[80vh]">
      
      <div className="w-full flex-1 flex flex-col justify-center items-center gap-8 py-10 relative">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
          <div className="w-[500px] h-[500px] rounded-full bg-primary-fixed-dim/5 blur-[100px] animate-pulse" />
        </div>

        <div className="relative z-10 flex flex-col items-center w-full">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ ease: [0.22, 1, 0.36, 1], duration: 0.6 }}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-primary-fixed-dim/20 mb-8 bg-surface-container/50 backdrop-blur-md"
            >
                <div className="w-1.5 h-1.5 rounded-full bg-primary-fixed-dim animate-[pulse_1.5s_infinite]" />
                <span className="font-label-caps text-[10px] text-primary-fixed-dim tracking-widest">ANALYZING ASSET TOPOLOGY</span>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl">
                <AnimatePresence>
                  {step >= 1 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
                      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                      transition={{ ease: [0.22, 1, 0.36, 1], duration: 0.8 }}
                    >
                      <GlassCard floating className="p-6 h-full">
                          <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-2">
                              <span className="font-label-caps text-outline">INITIAL SCARCITY CHECK</span>
                              <span className="material-symbols-outlined text-primary-fixed-dim text-lg">radar</span>
                          </div>
                          <div className="font-display-lg text-primary mb-2 drop-shadow-[0_0_10px_rgba(0,219,231,0.3)]">
                            94<span className="text-3xl text-outline-variant font-light">%</span>
                          </div>
                          <p className="font-body-md text-on-surface-variant text-sm">High demand in New Cairo sector. Inventory down 12% MoM.</p>
                      </GlassCard>
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {step >= 2 && (
                    <motion.div
                      initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
                      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                      transition={{ ease: [0.22, 1, 0.36, 1], duration: 0.8 }}
                    >
                      <GlassCard floating className="p-6 h-full">
                          <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-2">
                              <span className="font-label-caps text-outline">LOCATION PREMIUM</span>
                              <span className="material-symbols-outlined text-tertiary-fixed-dim text-lg">location_on</span>
                          </div>
                          <div className="font-display-lg text-tertiary-fixed-dim mb-2 drop-shadow-[0_0_10px_rgba(78,222,163,0.3)]">
                            +15<span className="text-3xl text-outline-variant font-light">%</span>
                          </div>
                          <p className="font-body-md text-on-surface-variant text-sm">Proximity to upcoming Monorail station adds significant baseline value.</p>
                      </GlassCard>
                    </motion.div>
                  )}
                </AnimatePresence>
            </div>
            
            <AnimatePresence mode="wait">
              {step >= 3 && (
                <motion.div 
                  key="typing"
                  className="mt-16 text-center max-w-2xl px-4"
                >
                  <p className="font-headline-lg-mobile md:font-headline-lg text-on-surface font-light leading-relaxed">
                    {"Analyzing historical transaction data and current micro-market sentiment... identifying optimal entry windows based on localized scarcity and emerging infrastructure signals.".split(" ").map((word, i) => (
                      <motion.span
                        key={i}
                        initial={{ opacity: 0, filter: "blur(8px)", y: 10 }}
                        animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                        transition={{ delay: i * 0.08, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                        className="inline-block mr-2"
                      >
                        {word}
                      </motion.span>
                    ))}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, ease: [0.22, 1, 0.36, 1], duration: 0.8 }}
        className="w-full max-w-2xl bg-surface-container-lowest/60 backdrop-blur-2xl border border-white/10 rounded-2xl p-4 shadow-2xl relative z-20 mt-auto"
      >
         <div className="mb-4 text-right">
             <div className="inline-block bg-surface-variant/40 border border-white/5 rounded-2xl rounded-tr-sm px-4 py-2">
                <p className="font-body-md text-on-surface text-sm">Is this property overpriced?</p>
             </div>
         </div>
         <div className="relative flex items-center group">
            <input 
                type="text" 
                placeholder="Command VALOR..." 
                className="w-full bg-surface/30 border border-white/10 rounded-xl px-5 py-4 text-on-surface focus:outline-none focus:border-primary-fixed-dim/40 transition-colors font-body-md text-sm group-hover:border-white/20"
                disabled
            />
            <button className="absolute right-3 w-10 h-10 rounded-full bg-primary/10 text-primary-fixed-dim flex items-center justify-center hover:bg-primary/20 hover:scale-105 transition-all">
                <span className="material-symbols-outlined text-[20px]">mic</span>
            </button>
         </div>
      </motion.div>

    </div>
  );
}
