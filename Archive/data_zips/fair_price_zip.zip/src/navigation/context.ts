import * as React from "react";

export type NavTab = "nexus" | "broker" | "pulse" | "assets" | "vault";

export const NavigationContext = React.createContext<{
  currentTab: NavTab;
  setTab: (tab: NavTab) => void;
}>({
  currentTab: "nexus",
  setTab: () => {},
});

export const useNavigation = () => React.useContext(NavigationContext);
