/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { NavigationContext, NavTab } from "./navigation/context";
import { TopNav } from "./components/layout/TopNav";
import { BottomNav } from "./components/layout/BottomNav";
import { ScreenTransition } from "./components/layout/ScreenTransition";
import { AnimatePresence } from "motion/react";

// Screens
import { NexusScreen } from "./features/nexus/NexusScreen";
import { BrokerScreen } from "./features/broker/BrokerScreen";
import { PulseScreen } from "./features/pulse/PulseScreen";
import { AssetsScreen } from "./features/assets/AssetsScreen";
import { VaultScreen } from "./features/vault/VaultScreen";

export default function App() {
  const [currentTab, setTab] = useState<NavTab>("nexus");

  return (
    <NavigationContext.Provider value={{ currentTab, setTab }}>
      <div className="flex flex-col min-h-screen bg-background text-on-background font-body-md selection:bg-primary-container selection:text-on-primary-container overflow-x-hidden relative">
        <TopNav />
        <BottomNav />
        
        <main className="flex-1 flex w-full relative z-10">
          <AnimatePresence mode="wait">
            <ScreenTransition key={currentTab}>
              {currentTab === "nexus" && <NexusScreen />}
              {currentTab === "broker" && <BrokerScreen />}
              {currentTab === "pulse" && <PulseScreen />}
              {currentTab === "assets" && <AssetsScreen />}
              {currentTab === "vault" && <VaultScreen />}
            </ScreenTransition>
          </AnimatePresence>
        </main>
      </div>
    </NavigationContext.Provider>
  );
}

