import * as React from "react";
import { motion } from "motion/react";

export function ScreenTransition({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98, filter: "blur(8px)" }}
      animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
      exit={{ opacity: 0, scale: 1.02, filter: "blur(8px)" }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="w-full flex-1 flex flex-col pt-24 pb-32 md:pl-72 max-w-[1600px] mx-auto overflow-x-hidden min-h-screen"
      {...props as any}
    >
      {children}
    </motion.div>
  );
}
