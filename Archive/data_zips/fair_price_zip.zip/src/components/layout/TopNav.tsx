import * as React from "react";
import { useNavigation } from "@/navigation/context";

export function TopNav() {
  const { currentTab } = useNavigation();

  return (
    <header className="fixed top-0 w-full z-50 flex justify-between items-center px-4 md:px-10 py-4 bg-surface/60 backdrop-blur-xl border-b border-white/10 shadow-[0_0_20px_rgba(0,219,231,0.1)]">
      <div className="flex items-center gap-2">
        <span className="material-symbols-outlined text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>blur_on</span>
        <span className="font-headline-lg-mobile md:font-headline-lg text-primary tracking-widest">VALOR AI</span>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="hidden md:flex gap-6 font-label-caps text-on-surface-variant text-xs">
          {currentTab === 'broker' && <span className="text-primary-fixed-dim px-3 py-1 border border-primary-fixed-dim/30 rounded-full bg-primary/10">AI STRATEGIST ACTIVE</span>}
          {currentTab === 'assets' && <span className="text-secondary-fixed">VALUATION ENGINE</span>}
        </div>
        
        <span className="material-symbols-outlined text-on-surface-variant hover:text-primary-container transition-colors cursor-pointer text-xl">notifications</span>
        
        <div className="w-8 h-8 rounded-full bg-primary-container/20 border border-primary-fixed-dim flex items-center justify-center cursor-pointer overflow-hidden relative">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary-fixed-dim/40 via-transparent to-transparent animate-pulse" />
          <span className="font-label-caps text-primary text-[10px] relative z-10">IN</span>
        </div>
      </div>
    </header>
  );
}
