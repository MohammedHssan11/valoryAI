import * as React from "react";
import { useNavigation, NavTab } from "@/navigation/context";
import { cn } from "@/lib/utils";
import { motion } from "motion/react";

export function BottomNav() {
  const { currentTab, setTab } = useNavigation();

  const tabs: { id: NavTab; icon: string; label: string }[] = [
    { id: "nexus", icon: "analytics", label: "Nexus" },
    { id: "broker", icon: "explore", label: "Broker" },
    { id: "pulse", icon: "map", label: "Pulse" },
    { id: "assets", icon: "real_estate_agent", label: "Assets" },
    { id: "vault", icon: "account_balance_wallet", label: "Vault" },
  ];

  return (
    <>
      {/* Mobile nav */}
      <nav className="md:hidden fixed bottom-0 w-full z-50 flex justify-around items-center px-6 pb-8 pt-4 bg-surface-container-lowest/80 backdrop-blur-2xl rounded-t-xl border-t border-white/5 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setTab(tab.id)}
              className={cn(
                "flex flex-col items-center justify-center p-3 transition-all",
                isActive 
                  ? "bg-primary/10 text-primary-fixed-dim rounded-full shadow-[0_0_15px_rgba(0,219,231,0.3)] scale-110 duration-500 ease-out" 
                  : "text-outline hover:text-primary-fixed"
              )}
            >
              <span 
                className="material-symbols-outlined text-[24px]"
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {tab.icon}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Desktop side nav (partial, shown on larger screens) */}
      <aside className="hidden md:flex fixed inset-y-0 left-0 z-[40] flex-col p-6 w-72 rounded-r-xl bg-surface-dim/95 backdrop-blur-3xl border-r border-primary/20 shadow-2xl shadow-primary/5 pt-32">
        <div className="flex flex-col gap-2">
           {tabs.map((tab) => {
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setTab(tab.id)}
                className={cn(
                  "flex items-center gap-4 p-3 rounded-lg transition-all duration-300 text-left",
                  isActive
                    ? "bg-secondary-container/30 text-secondary-fixed border-l-4 border-secondary-fixed pl-4"
                    : "text-on-surface-variant hover:bg-white/5 hover:pl-4 hover:text-primary-fixed"
                )}
              >
                <span className="material-symbols-outlined" style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}>
                  {tab.icon}
                </span>
                <span className="font-body-md whitespace-nowrap uppercase text-sm tracking-wider font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </aside>
    </>
  );
}
