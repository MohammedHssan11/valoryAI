import * as React from "react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "motion/react";

export type OrbState = "idle" | "thinking" | "analyzing" | "responding";

interface AiOrbProps {
  className?: string;  
  size?: "sm" | "md" | "lg" | "xl";
  state?: OrbState;
}

export function AiOrb({ className, size = "md", state = "idle", ...props }: AiOrbProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-16 h-16",
    lg: "w-32 h-32",
    xl: "w-64 h-64",
  };

  const getCoreStyles = () => {
    switch (state) {
      case "thinking":
        return "bg-gradient-to-br from-tertiary-fixed-dim/60 to-primary-fixed-dim/30 shadow-[0_2px_15px_rgba(111,251,190,0.2)] scale-100";
      case "analyzing":
        return "bg-gradient-to-br from-secondary-fixed/50 to-primary-fixed/30 shadow-[0_2px_20px_rgba(225,224,255,0.2)] scale-[0.98]";
      case "responding":
        return "bg-gradient-to-br from-primary-fixed/70 to-primary-container/70 shadow-[0_4px_30px_rgba(0,219,231,0.3)] scale-100";
      case "idle":
      default:
        return "bg-surface-tint shadow-[0_2px_10px_rgba(0,219,231,0.15)] scale-100";
    }
  };

  const getOuterGlow = () => {
    switch (state) {
      case "thinking":
        return "bg-tertiary-fixed-dim/10 blur-[30px] animate-[pulse_4s_infinite_ease-in-out]";
      case "analyzing":
        return "bg-secondary-fixed/10 blur-[24px] animate-[pulse_3s_infinite_ease-in-out]";
      case "responding":
        return "bg-primary-fixed/15 blur-[40px] animate-[pulse_2s_infinite_ease-in-out]";
      case "idle":
      default:
        return "bg-primary-fixed-dim/5 blur-[20px]";
    }
  };

  return (
    <motion.div
      variants={{
        idle: { scale: 1 },
        thinking: { scale: [1, 1.02, 1] },
        analyzing: { scale: [1, 0.98, 1] },
        responding: { scale: [1, 1.04, 1] }
      }}
      animate={state}
      transition={{ repeat: Infinity, duration: state === 'analyzing' ? 2 : 4, ease: "easeInOut" }}
      className={cn(
        "relative flex items-center justify-center rounded-full",
        sizeClasses[size],
        className
      )}
      {...props as any}
    >
      <motion.div 
        layout
        className={cn("absolute inset-0 rounded-full transition-all duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)]", getOuterGlow())} 
      />
      <div className={cn("absolute w-3/4 h-3/4 rounded-full mix-blend-screen opacity-60 orb-pulse transition-all duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)]", 
        state === "idle" ? "bg-gradient-to-br from-primary-container/40 to-secondary-container/40 blur-md" : "blur-lg bg-white/5")} 
      />
      
      <motion.div 
        layout
        className={cn("relative w-1/2 h-1/2 rounded-full transition-all duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)]", getCoreStyles())} 
      />
      
      {/* Outer rings */}
      <motion.div 
        animate={{ rotate: state === 'analyzing' ? 360 : 180 }}
        transition={{ duration: state === 'analyzing' ? 30 : 60, repeat: Infinity, ease: "linear" }}
        className={cn(
            "absolute inset-0 border rounded-full transition-colors duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)]",
            state === 'thinking' ? "border-tertiary-fixed-dim/10" : 
            state === 'analyzing' ? "border-secondary-fixed/10" : "border-primary-fixed-dim/5"
        )} 
      />
      <motion.div 
        animate={{ rotate: state === 'analyzing' ? -360 : -180 }}
        transition={{ duration: state === 'analyzing' ? 40 : 80, repeat: Infinity, ease: "linear" }}
        className={cn(
            "absolute -inset-2 border border-dashed rounded-full transition-colors duration-1000 ease-[cubic-bezier(0.22,1,0.36,1)]",
            state === 'thinking' ? "border-tertiary-fixed/10" : 
            state === 'analyzing' ? "border-secondary-fixed/10" : "border-secondary-fixed/5"
        )} 
      />

      {/* Interactive Micro-particles tracking orb status */}
      <AnimatePresence>
         {state === 'thinking' && (
            <motion.div 
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: [0, 0.4, 0], scale: [0.5, 1.1, 0.5] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="absolute inset-0 rounded-full border border-tertiary-fixed-dim/20 mix-blend-screen"
            />
         )}
      </AnimatePresence>
    </motion.div>
  );
}
