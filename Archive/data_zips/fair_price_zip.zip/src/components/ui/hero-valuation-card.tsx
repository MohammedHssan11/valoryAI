import * as React from "react";
import { cn } from "@/lib/utils";
import { GlassCard } from "./glass";
import { motion, AnimatePresence } from "motion/react";

const SPARKLINE_DATA = [
  { x: 0, y: 30, date: "APR '24", price: "10.2" },
  { x: 15, y: 28, date: "MAY '24", price: "10.6" },
  { x: 30, y: 31, date: "JUN '24", price: "10.1" },
  { x: 50, y: 20, date: "JUL '24", price: "11.2" },
  { x: 70, y: 10, date: "AUG '24", price: "12.8" },
  { x: 85, y: 14, date: "SEP '24", price: "11.8" },
  { x: 100, y: 10, date: "OCT '24", price: "12.45" },
];

export interface HeroValuationCardProps {
  value: string;
  currencyPrefix?: string;
  currencySuffix?: string;
  upside?: string;
  confidence?: string;
  trend?: "up" | "down" | "neutral";
  isLoading?: boolean;
  className?: string;
}

export function HeroValuationCard({
  value,
  currencyPrefix = "EGP",
  currencySuffix = "M",
  upside = "+1.2%",
  confidence = "High",
  trend = "up",
  isLoading = false,
  className,
}: HeroValuationCardProps) {
  const [showConfidenceDetails, setShowConfidenceDetails] = React.useState(false);
  const [hoverIndex, setHoverIndex] = React.useState<number | null>(null);

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    
    let closestIdx = 0;
    let minD = Infinity;
    SPARKLINE_DATA.forEach((d, i) => {
      const dist = Math.abs(d.x - x);
      if (dist < minD) {
        minD = dist;
        closestIdx = i;
      }
    });
    setHoverIndex(closestIdx);
  };

  const handlePointerLeave = () => {
    setHoverIndex(null);
  };

  if (isLoading) {
    return (
      <div className={cn("relative flex items-center justify-center w-full max-w-2xl mx-auto", className)}>
         <div className="relative w-72 h-72 md:w-96 md:h-96 flex items-center justify-center mb-6">
            <div className="absolute inset-0 rounded-full border border-primary-fixed-dim/10 animate-[pulse_3s_ease-in-out_infinite]" />
            <div className="absolute inset-4 rounded-full border border-primary-fixed-dim/5 border-dashed animate-[spin_60s_linear_infinite]" />
            <div className="flex flex-col items-center gap-2">
                 <div className="w-24 h-4 bg-surface-variant rounded animate-pulse" />
                 <div className="w-48 h-12 bg-surface-variant rounded-lg animate-pulse mt-2" />
                 <div className="w-32 h-6 bg-surface-variant rounded animate-pulse mt-4" />
            </div>
         </div>
         <GlassCard className="w-full p-6 animate-pulse mt-8 h-24" />
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, filter: "blur(10px)" }}
      animate={{ opacity: 1, filter: "blur(0px)" }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={cn("relative flex flex-col items-center justify-center w-full max-w-2xl mx-auto", className)}
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="mb-8 flex items-center gap-2 px-4 py-2 rounded-full bg-primary-fixed-dim/5 border border-primary-fixed-dim/15 text-primary-fixed-dim font-label-caps text-xs"
      >
          <span className="w-2 h-2 rounded-full bg-primary-fixed-dim shadow-[0_0_8px_rgba(0,219,231,0.4)] animate-[pulse_2s_infinite]" />
          MARKET POSITION: UNDERVALUED
      </motion.div>

      <div className="relative w-72 h-72 md:w-96 md:h-96 flex items-center justify-center mb-8">
        <div className="absolute inset-0 rounded-full border border-primary-fixed-dim/20 orb-pulse mix-blend-screen" />
        <div className="absolute inset-4 rounded-full border border-primary-fixed-dim/10 border-dashed animate-[spin_120s_linear_infinite]" />
        
        <div className="relative z-10 text-center flex flex-col items-center">
            <motion.span 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="font-label-caps text-on-surface-variant mb-2 tracking-widest"
            >
              ESTIMATED VALUE
            </motion.span>
            
            <motion.h1 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, ease: [0.22, 1, 0.36, 1], duration: 0.8 }}
              className="font-display-lg text-primary tracking-tighter drop-shadow-[0_0_15px_rgba(0,219,231,0.3)]"
            >
                <span className="text-3xl align-top text-primary/70 mr-1 font-light">{currencyPrefix}</span>
                {value}
                <span className="text-3xl text-primary/70 ml-1 font-light">{currencySuffix}</span>
            </motion.h1>
            
            <motion.div 
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className={cn(
                "relative overflow-hidden mt-4 flex items-center gap-1 font-data-tabular px-3 py-1.5 rounded-lg border",
                trend === 'up' ? "text-tertiary-fixed-dim bg-tertiary-fixed-dim/5 border-tertiary-fixed-dim/20 shadow-[0_0_10px_rgba(78,222,163,0.1)]" :
                trend === 'down' ? "text-error bg-error/5 border-error/20" :
                "text-primary-fixed bg-primary-fixed/5 border-primary-fixed/20"
              )}
            >
                {trend === 'up' && (
                  <motion.div
                    animate={{ x: ["-100%", "250%"] }}
                    transition={{
                      repeat: Infinity,
                      duration: 2.5,
                      ease: "linear",
                      repeatDelay: 1.5
                    }}
                    className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12"
                  />
                )}
                <span className="relative z-10 material-symbols-outlined text-[16px]">
                  {trend === 'up' ? 'trending_up' : trend === 'down' ? 'trending_down' : 'trending_flat'}
                </span>
                <span className="relative z-10">
                  {upside} <span className="text-on-surface-variant text-[12px] ml-1 font-light">vs 30d</span>
                </span>
            </motion.div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, ease: [0.22, 1, 0.36, 1], duration: 0.8 }}
        className="w-full relative z-20"
      >
        <GlassCard className="w-full p-6 flex flex-col gap-4">
            <div className="flex justify-between items-end">
                <span className="font-label-caps text-on-surface-variant">VALUATION SPECTRUM</span>
                <div className="relative">
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setShowConfidenceDetails(!showConfidenceDetails)}
                    className="font-data-tabular text-primary-fixed-dim flex items-center gap-1 hover:text-primary transition-colors focus:outline-none"
                  >
                    Confidence: {confidence}
                    <span className="material-symbols-outlined text-[14px]">info</span>
                  </motion.button>
                  <AnimatePresence>
                    {showConfidenceDetails && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95, filter: "blur(4px)" }}
                        animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
                        exit={{ opacity: 0, y: 10, scale: 0.95, filter: "blur(4px)" }}
                        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                        className="absolute bottom-full right-0 mb-4 w-72 z-50 origin-bottom-right"
                      >
                        <GlassCard className="p-4 shadow-2xl border-primary-fixed-dim/20 backdrop-blur-2xl">
                          <div className="flex items-center gap-2 mb-3 border-b border-white/5 pb-2">
                            <span className="material-symbols-outlined text-tertiary-fixed-dim text-[16px]">psychology</span>
                            <span className="font-label-caps text-on-surface">AI RATIONALE</span>
                          </div>
                          <ul className="flex flex-col gap-3 font-body-md text-sm text-on-surface-variant text-left">
                            <motion.li initial={{ opacity: 0, x: 5 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }} className="flex items-start gap-2">
                              <span className="material-symbols-outlined text-[16px] text-tertiary-fixed-dim mt-0.5">check_circle</span>
                              <span>Analyzed <strong className="text-on-surface">1,402</strong> real-time data points</span>
                            </motion.li>
                            <motion.li initial={{ opacity: 0, x: 5 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="flex items-start gap-2">
                              <span className="material-symbols-outlined text-[16px] text-tertiary-fixed-dim mt-0.5">check_circle</span>
                              <span>Cross-referenced <strong className="text-on-surface">84</strong> direct comps within 2km</span>
                            </motion.li>
                            <motion.li initial={{ opacity: 0, x: 5 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="flex items-start gap-2">
                              <span className="material-symbols-outlined text-[16px] text-primary-fixed-dim mt-0.5">analytics</span>
                              <span>Model variance calculated at <strong className="text-on-surface">±1.2%</strong></span>
                            </motion.li>
                          </ul>
                        </GlassCard>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
            </div>
            
            <div className="h-16 w-full relative mb-1 mt-2">
              <svg 
                className="w-full h-full overflow-visible touch-none cursor-crosshair" 
                preserveAspectRatio="none" 
                viewBox="0 0 100 40"
                onPointerMove={handlePointerMove}
                onPointerLeave={handlePointerLeave}
                onPointerDown={handlePointerMove}
              >
                <defs>
                  <linearGradient id="cyan-gradient" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#00dbe7" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#00dbe7" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <motion.path 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1, duration: 1.5, ease: "easeOut" }}
                  className="fill-[url(#cyan-gradient)]" 
                  d="M0,40 L0,30 C20,25 30,35 50,20 C70,5 80,15 100,10 L100,40 Z" 
                />
                <motion.path 
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.7, duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
                  className="stroke-primary-fixed-dim fill-none drop-shadow-[0_0_6px_rgba(0,219,231,0.5)]" 
                  strokeWidth="1.5" 
                  d="M0,30 C20,25 30,35 50,20 C70,5 80,15 100,10" 
                />
                
                {hoverIndex === null && (
                  <>
                    <motion.circle initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 2, type: "spring" }} cx="100" cy="10" fill="#111417" r="2.5" stroke="#00dbe7" strokeWidth="1.5" />
                    <motion.circle initial={{ opacity: 0 }} animate={{ scale: [1, 2.5], opacity: [0.6, 0] }} transition={{ repeat: Infinity, duration: 3, ease: "easeOut", delay: 2 }} className="origin-center" cx="100" cy="10" fill="none" r="3" stroke="#00dbe7" strokeWidth="1" />
                  </>
                )}

                {hoverIndex !== null && (
                  <g>
                    <line x1={SPARKLINE_DATA[hoverIndex].x} y1={0} x2={SPARKLINE_DATA[hoverIndex].x} y2={40} stroke="#00dbe7" strokeWidth={0.5} strokeDasharray="2 2" opacity={0.4} />
                    <circle cx={SPARKLINE_DATA[hoverIndex].x} cy={SPARKLINE_DATA[hoverIndex].y} r="2.5" fill="#111417" stroke="#00dbe7" strokeWidth="1.5" />
                    <circle cx={SPARKLINE_DATA[hoverIndex].x} cy={SPARKLINE_DATA[hoverIndex].y} r="8" fill="#00dbe7" opacity="0.2" className="animate-pulse origin-center" />
                  </g>
                )}
              </svg>

              <AnimatePresence>
                {hoverIndex !== null && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.2, ease: "easeOut" }}
                    className="absolute -top-12 pointer-events-none z-10"
                    style={{ left: `calc(${Math.min(Math.max(SPARKLINE_DATA[hoverIndex].x, 8), 92)}% - 40px)`, width: '80px' }}
                  >
                    <div className="flex flex-col items-center justify-center bg-surface-container-highest/90 backdrop-blur-md border border-primary-fixed-dim/20 rounded px-2 py-1 shadow-[0_4px_15px_rgba(0,0,0,0.5)]">
                      <span className="font-label-caps text-[9px] text-outline whitespace-nowrap">{SPARKLINE_DATA[hoverIndex].date}</span>
                      <span className="font-data-tabular text-[11px] text-primary-fixed drop-shadow-[0_0_2px_rgba(0,219,231,0.5)] font-medium">{currencyPrefix}{SPARKLINE_DATA[hoverIndex].price}{currencySuffix}</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <div className="relative h-1.5 w-full bg-surface-container-highest rounded-full overflow-hidden mt-2">
                <motion.div 
                  initial={{ opacity: 0 }} animate={{ opacity: 0.8 }} transition={{ delay: 1, duration: 1 }}
                  className="absolute inset-0 bg-gradient-to-r from-tertiary-fixed-dim/80 via-primary-fixed-dim/80 to-error/80" 
                />
                <motion.div 
                  initial={{ left: "0%" }}
                  animate={{ left: "35%" }}
                  transition={{ delay: 0.8, duration: 1.5, type: "spring", stiffness: 40, damping: 15 }}
                  className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_10px_#fff]" 
                />
            </div>
            
            <div className="flex justify-between font-label-caps text-[9px] text-outline opacity-80">
                <span>UNDERVALUED</span>
                <span>FAIR VALUE</span>
                <span>OVERVALUED</span>
            </div>
        </GlassCard>
      </motion.div>
    </motion.div>
  );
}
